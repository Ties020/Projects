const form = document.getElementById('form')
const filterContainer = document.querySelector('#filter-container');
window.onload = maketable()
async function maketable()
{
  console.log("loaded")
  x = 0                                              //variable used for giving each row a rownumber
  initialArray = ['']                                //used for checking if author is already being displayed
  arrayPostInteraction = ['']
  arrayauthor2=['']
  arrayauthor3=['']
  let url = "https://wt.ops.labs.vu.nl/api23/e4e4ee84";
  let response = await fetch(url);
  if(response.status === 200)
  {
    let info = await response.json();
    
      for (h of info){
      for(var i=0; i< arrayauthor3.length; ++i){
        if (arrayauthor3.includes(h.author)){break;}
        else
        {
          const domElement = document.createElement('span');
          domElement.innerText = h.author;
          domElement.classList.add('filter-element');
          domElement.id=h.author;
          domElement.addEventListener('click', filterImages)
          filterContainer.appendChild(domElement);
          arrayauthor2.push(h.author)
          arrayauthor3.push(h.author)
        }
      }
    }
    
    for(h of info)
    {
      for(var i=0; i< initialArray.length; ++i)
      {
        if (initialArray.includes(h.author))       //give images of author an id, namely name of the author, to call this id and the id imagecollection when filtering
        { 
           if(arrayauthor2.includes(h.image)){break;}
          else
          {
          const domElement = document.getElementById('img-class')
          let authorImage = new Image()          
          authorImage.src = h.image
          authorImage.classList.add("imagecollection")
          authorImage.classList.add("hide-image")
          authorImage.setAttribute("id",h.author) 
          domElement.appendChild(authorImage);
          arrayauthor2.push(h.image)
          }   
        }
        else
        {                                                   //add author data to grid and display it when non-duplicate
          const spaceForInitialAuthors = document.getElementById("div1")
          const initialRow = document.createElement("div")
          initialRow.setAttribute("class","roo")
          initialRow.setAttribute("id",`${x}`)

          const standim = document.createElement("div")
          const im = new Image()
          im.src = h.image
          standim.classList.add("col","imagecollection")
          standim.setAttribute("id",h.author) 
          standim.appendChild(im)
          initialRow.appendChild(standim)


          const standname = document.createElement("div")
          const node2 = document.createTextNode(h.author)
          standname.setAttribute("class","col")
          standname.appendChild(node2)
          initialRow.appendChild(standname)
          
          const standalt = document.createElement("div")
          const node3 = document.createTextNode(h.alt);
          standalt.setAttribute("class","col")
          standalt.appendChild(node3)
          initialRow.appendChild(standalt)

          const standtags = document.createElement("div")
          const node4 = document.createTextNode(h.tags);
          standtags.setAttribute("class","col")
          standtags.appendChild(node4)
          initialRow.appendChild(standtags)

          const standdes = document.createElement("div")
          const node5 = document.createTextNode(h.description);
          standdes.setAttribute("class","col")
          standdes.appendChild(node5)
          initialRow.appendChild(standdes)
      
          spaceForInitialAuthors.appendChild(initialRow)
          initialArray.push(h.author)
          arrayPostInteraction.push(h.author)
          arrayauthor2.push(h.image)
          x+=1
        }
      } 
    }
  }
}

form.addEventListener('submit', async function(event)            //add new author to grid if not present already and add its name to postInteraction array...
{                                                                 //use postInteraction array to check whether author is already present
  event.preventDefault()
  if (arrayPostInteraction.includes(document.getElementById('author').value))
  {
    alert("Author has already been registered")
  }
  else
  {
    var imagelink=document.getElementById('image').value
    var name=document.getElementById('author').value
    var alts=document.getElementById('alt').value
    var tagslink=document.getElementById('tags').value
    var des=document.getElementById('des').value


    const spaceForNewAuthors = document.getElementById("div2")
    const newRow = document.createElement("div")
    newRow.setAttribute("class","roo")
    newRow.setAttribute("id",`${x}`)                           
    const newimbox = document.createElement("div")
    const newim = new Image()
    newim.src = imagelink
    newimbox.classList.add("col", "imagecollection")
    newimbox.setAttribute('id', name)
    newimbox.appendChild(newim)
    newRow.appendChild(newimbox)
    
    const newname = document.createElement("div")
    const node2 = document.createTextNode(name);
    newname.setAttribute("class","col")
    newname.appendChild(node2)
    newRow.appendChild(newname)

    const newalt = document.createElement("div")
    const node3 = document.createTextNode(alts);
    newalt.setAttribute("class","col")
    newalt.appendChild(node3)
    newRow.appendChild(newalt)

    const newtag = document.createElement("div")
    const node4 = document.createTextNode(tagslink);
    newtag.setAttribute("class","col")
    newtag.appendChild(node4)
    newRow.appendChild(newtag)

    const newdes = document.createElement("div")
    const node5 = document.createTextNode(des);
    newdes.setAttribute("class","col")
    newdes.appendChild(node5)
    newRow.appendChild(newdes)

    const newauthortag = document.createElement('span');                          //
    const node6 = document.createTextNode(name);
   newauthortag.setAttribute('class', 'filter-element');
   newauthortag.setAttribute('id', name);
    let newsome = document.getElementById('filter-container')
    newauthortag.appendChild(node6) 
    newsome.appendChild(newauthortag)
    newauthortag.addEventListener('click', filterImages) 

    spaceForNewAuthors.appendChild(newRow)

    arrayPostInteraction.push(name)
    x+=1

    fetch("https://wt.ops.labs.vu.nl/api23/e4e4ee84",  //post new author to the web server
    {    
      method: 'POST',
      body: JSON.stringify(
      {
        image: imagelink,
        author: name,
        alt: alts,
        tags: tagslink,
        description: des
      }),
      headers: 
      {
        'Content-type': 'application/json'
      }
      })
      .then(function(response)
      { 
      return response.json()})
      .then(function()
      {
        console.log(JSON.stringify(
        {
        image: imagelink,
        author: name,
        alt: alts,
        tags: tagslink,
        description: des
        }))
      })
      .catch(error => console.error('Error:', error)); 
    }
})

async function updateAuthor()
{
  var rownumber = document.getElementById('rown').value
  var filterData = document.getElementById('filter-container') 
  var authorData = document.getElementById(rownumber)
  var newname=document.getElementById('upauthor').value
  console.log("called")
  var rowname = authorData.childNodes[1].innerHTML
  let url = "https://wt.ops.labs.vu.nl/api23/e4e4ee84";
  let response = await fetch(url);
  
  if(response.status === 200)                       //use this condition and loop to get the id of the author from the web server
  {
    let info = await response.json();
    for(h of info)
    {
      if(rowname === h.author)
      {
        var myid = h.id
        break;
      }
    }
  }

  var newimagelink=document.getElementById('upimage').value
  var newalts=document.getElementById('upalt').value
  var newtags=document.getElementById('uptags').value
  var newdes=document.getElementById('updes').value

  var im = "<img src=\"" + newimagelink + "\">";
  authorData.childNodes[0].innerHTML = im     
  authorData.childNodes[0].id = newname          //update all data of the author with rownumber that was entered
  authorData.childNodes[1].innerHTML = newname
  authorData.childNodes[2].innerHTML = newalts
  authorData.childNodes[3].innerHTML = newtags
  authorData.childNodes[4].innerHTML = newdes  
  filterData.childNodes[rownumber].innerHTML = newname
  filterData.childNodes[rownumber].setAttribute('id', newname)

  arrayPostInteraction.push(newname)
  arrayPostInteraction = arrayPostInteraction.filter(function (letter)         // remove old author name from array when updated
  {
    return letter !== rowname;
  });
  x+=1
  
  const newdata = 
  {
    method: 'PUT',
    body: JSON.stringify(
    {
      image: newimagelink,
      author: newname,
      alt: newalts,
      tags: newtags,
      description: newdes
    }),
    headers: 
    {
      'Content-type': 'application/json'
    }
  }
  fetch("https://wt.ops.labs.vu.nl/api23/e4e4ee84/item/" +`${myid}`,newdata)
    .then(function()
    {
      console.log(JSON.stringify(
      {
        image: newimagelink,
        author: newname,
        alt: newalts,
        tags: newtags,
        description: newdes
      }))
    })
}
const but = document.getElementById("updatebtn")
but.addEventListener("click", async function()
{
  var rownumber = document.getElementById('rown').value
  var authorData = document.getElementById(rownumber)
  var newname=document.getElementById('upauthor').value
  
  if (arrayPostInteraction.includes(document.getElementById('upauthor').value)) //check if author is already in table and is being entered in a different row, in which case we alert that this isnt possible
  {
    if(newname !== authorData.childNodes[1].innerHTML)
    {
      alert("Author has already been registered")
    }
    else                         //if author is being updated in the same row it will just change the data to the user input by calling function updateAuthor
    {
      updateAuthor()
    }
  }
  else              //if authorname is not yet in the gallery, update the old one and replace it with the new one by calling updateAuthor
  {
    updateAuthor()
  }

  })

const resetfunc = document.getElementById('reset')
resetfunc.addEventListener('click', async function(event)//when reset button is clicked, whole page is emptied and filled with initial data by calling function maketable
{ 
  event.preventDefault()
  let galleryPreInput = document.getElementById("div1")
  galleryPreInput.innerHTML = ''
  let galleryPostInput = document.getElementById("div2")
  galleryPostInput.innerHTML = ''
  let galleryPostInput1 = document.getElementById("filter-container")
  galleryPostInput1.innerHTML = ''
  let galleryPostInput2 = document.getElementById("img-class")
  galleryPostInput2.innerHTML = ''
  await fetch("https://wt.ops.labs.vu.nl/api23/e4e4ee84/reset")
  maketable()
})

  
const filterImages2=(event)=>
{
  let galleryPreInput = document.getElementById("div1")
  galleryPreInput.innerHTML = ''
  let galleryPostInput = document.getElementById("div2")
  galleryPostInput.innerHTML = ''
  let galleryPostInput1 = document.getElementById("filter-container")
  galleryPostInput1.innerHTML = ''
  let galleryPostInput2 = document.getElementById("img-class")
  galleryPostInput2.innerHTML = ''
  maketable();
}

const filterImages = (event) => {
  document.querySelectorAll('.filter-element').forEach
  (element => 
  {
    element.classList.remove('filter-active')
  })
    event.target.classList.add('filter-active');
    event.target.addEventListener('click', filterImages2)

  document.querySelectorAll('.imagecollection').forEach(element =>
  {
    if(event.target.id === element.id)
    {
      element.classList.remove('hide-image');
      element.parentNode.classList.remove('hidenode');
    }
    else{
      element.classList.add('hide-image');
      element.parentNode.classList.add('hidenode');
    }
  })
};
