const sqlite = require('sqlite3').verbose();
let db = my_database('./gallery.db');

//const {response} = require('express');

var express = require("express");
var app = express();

app.use(express.json());

app.get("/gallery", function(req,res) 
{
   db.all("SELECT * FROM gallery", function(err, rows)
	{
		res.setHeader('Content-Type', 'json/application');
		return res.status(200).json(rows);    //return data of all items of the database in json format, as the response body
	})
});

app.post('/gallery', function(req, res) 
{
	const author = req.body.author;
	const alt = req.body.alt;
	const tags = req.body.tags;
	const image = req.body.image;
	const description = req.body.description;

	db.run(`INSERT INTO gallery (author, alt, tags, image, description) VALUES (?, ?, ?, ?, ?)`, [author, alt, tags, image, description], function(err)
	{
		if(err)
		{
			return res.status(400).json({"Error":"Bad request"}); // returns error due to client error
		}
		else
		{
			return res.status(201).json({"Status":"author has been posted"}); //post request has been successful, new recourse was created
		}
	});
});

app.put('/gallery/:id', function(req, res)
{
	const id = req.params.id;
	const author = req.body.author;
	const alt = req.body.alt;
	const tags = req.body.tags;
	const image = req.body.image;
	const description =req.body.description;

	db.all(`SELECT * FROM gallery WHERE id= ?`,[req.params.id], function(err, rows) 
	{
		if(rows.length == 0 || err)
		{
			return res.status(404).json({"Error":"Invalid ID"}); //returns error Not Found, if id is invalid
		}
		else{
			db.run(`UPDATE gallery SET author=?, alt=?, tags=?, image=?, description=? WHERE id=?`, [author, alt, tags, image, description, id], function(err)
			{
				if(err)
				{
					return res.status(400).json({"Error":"Bad request"}); // returns error due to client error 
				}
				else
				{
					return res.status(201).json({"Status":"Author has been updated"}); //put request has been successful, new recourse was created
				}
			})
		}
	})
});

app.get('/gallery/:id', function(req, res) {
	var itemID = req.params.id;
	res.setHeader('Content-Type', 'json/application');
	db.all(`SELECT * FROM gallery WHERE id=?`,[itemID], function(err, rows) {
		if (rows.length == 0)                          //return 404(NOT FOUND)code if there's no existent item with the id in the given parameter
		{
			return res.status(404).json({"Error":"Invalid ID"});
		}
		else
		{
			return res.json(rows);
		}})
});

app.delete('/gallery/:id', function(req, res) 
{
	var itemID = req.params.id;
	res.setHeader('Content-Type', 'json/application')
	db.all(`SELECT * FROM gallery WHERE id= ?`,[itemID], function(err, rows) 
	{
		db.run(`DELETE FROM gallery WHERE id= ?`,[itemID], function() 
		{
			if(rows.length == 0)                          //return 404(NOT FOUND)code if there's no existent item with the id in the given parameter
			{
				return res.status(404).json({"Error":"Invalid ID"});
			}
			else
			{
				res.status(200).json({"Status":"Deleted element"});
			}
		})
	})
});

app.listen(3000);
console.log("Your Web server should be up and running, waiting for requests to come in.");

function my_database(filename) 
{
	var db = new sqlite.Database(filename, (err) => 
	{
  		if (err) 
		{
			console.error(err.message);
  		}
  		console.log('Connected to the phones database.');
	});
	db.serialize(() =>             //this code is to create the table in the database
	{
		db.run(`
        	CREATE TABLE IF NOT EXISTS gallery         
        	 (
                    id INTEGER PRIMARY KEY,
                    author CHAR(100) NOT NULL,
                    alt CHAR(100) NOT NULL,
                    tags CHAR(256) NOT NULL,
                    image char(2048) NOT NULL,
                    description CHAR(1024) NOT NULL
		 )
		`);
		db.all(`select count(*) as count from gallery`, function(err, result) 
		{
			if (result[0].count == 0) 
			{
				db.run(`INSERT INTO gallery (author, alt, tags, image, description) VALUES (?, ?, ?, ?, ?)`, [
        			"Tim Berners-Lee",
        			"Image of Berners-Lee",
        			"html,http,url,cern,mit",
        			"https://upload.wikimedia.org/wikipedia/commons/9/9d/Sir_Tim_Berners-Lee.jpg",
        			"The internet and the Web aren't the same thing."
    				]);
				db.run(`INSERT INTO gallery (author, alt, tags, image, description) VALUES (?, ?, ?, ?, ?)`, [
        			"Grace Hopper",
        			"Image of Grace Hopper at the UNIVAC I console",
        			"programming,linking,navy",
        			"https://upload.wikimedia.org/wikipedia/commons/3/37/Grace_Hopper_and_UNIVAC.jpg",
				"Grace was very curious as a child; this was a lifelong trait. At the age of seven, she decided to determine how an alarm clock worked and dismantled seven alarm clocks before her mother realized what she was doing (she was then limited to one clock)."
    				]);
				db.run(`INSERT INTO gallery (author, alt, tags, image, description) VALUES (?, ?, ?, ?, ?)`, [
				"John Cena",
				"SHould be an image of John Cena",
				"wwe,actor,wrestler,invisible",
				"https://b.fssta.com/uploads/application/wwe/headshots/john-cena.vresize.350.350.medium.11.png",
				"Hustle, Loyalty and Respect."
					]);
				console.log('Inserted dummy photo entry into empty database');
			} 
		else 
		{
			console.log("Database already contains", result[0].count, " item(s) at startup.");
		}
		});
	});
	return db;
}